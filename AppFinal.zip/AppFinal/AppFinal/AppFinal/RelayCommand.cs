﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace AppFinal
{
    class RelayCommand : ICommand
    {
        public RelayCommand(Action<object> execute) : this(execute, null)
        {
        }
        public RelayCommand(Action<object> execute, Predicate<object> canExecute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");
            execute1 = execute;
            canExecute1 = canExecute;
        }
        public bool CanExecute(object parameter)
        {
            return canExecute1 == null ? true : canExecute1(parameter);
        }
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
        public void Execute(object parameter)
        {
            execute1(parameter);
        }
        private readonly Action<object> execute1;
        private readonly Predicate<object> canExecute1;
    }
    

}
