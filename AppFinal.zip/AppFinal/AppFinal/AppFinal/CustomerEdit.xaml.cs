﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppFinal
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class CustomerEdit : Window
    {
        public CustomerEdit()
        {
            InitializeComponent();

        }

        private void Button_Click(object sender, RoutedEventArgs e) //get
        {
            var cs = Properties.Settings.Default.ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                String Name = "";
                String Address = "";
                String City = "";
                String State = "";
                String Phone = "";
                String Zip = "";

                try
                {
                    using (var cmd = new SqlCommand("SELECT Name, Address, City, State, Phone, ZipCode FROM Customers WHERE CustomerID = @CustomerID", con))
                    {
                        cmd.Parameters.AddWithValue("@CustomerID", IDSearch.Text);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read()) // Don't assume we have any rows.
                            {
                                int ord = reader.GetOrdinal("Name");
                                Name = reader.GetString(ord); // Handles nulls and empty strings.
                                ord = reader.GetOrdinal("Address");
                                Address = reader.GetString(ord);
                                ord = reader.GetOrdinal("City");
                                City = reader.GetString(ord);
                                ord = reader.GetOrdinal("State");
                                State = reader.GetString(ord);
                                ord = reader.GetOrdinal("Phone");
                                Phone = reader.GetString(ord);
                                ord = reader.GetOrdinal("ZipCode");
                                Zip = reader.GetString(ord);
                            }

                            NameTB.Text = Name;
                            AddressTB.Text = Address;
                            CityTB.Text = City;
                            StateTB.Text = State;
                            PhoneTB.Text = Phone;
                            ZipTB.Text = Zip;
                        }
                    }
                }
                catch(SqlException ex)
                {
                    throw ex;
                }

                finally
                { 
                    con.Close();
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //add
        {
            var confirmResult = MessageBox.Show("Are you sure you want to Add this item??",
                                     "Confirm Add!!",
                                     MessageBoxButton.OKCancel);
            string yes = confirmResult.ToString();

            if (yes.Equals("OK"))
            {
                // If 'Yes', do something here.
                var cs = Properties.Settings.Default.ConnectionString;

                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    try
                    {

                        using (var cmd = new SqlCommand("INSERT INTO Customers VALUES (@CustomerID, @Name, @Address, @City, @Phone, @ZipCode, @State)", con))
                        {
                            cmd.Parameters.AddWithValue("@CustomerID", IDSearch.Text);
                            cmd.Parameters.AddWithValue("@Name", NameTB.Text);
                            cmd.Parameters.AddWithValue("@Address", AddressTB.Text);
                            cmd.Parameters.AddWithValue("@City", CityTB.Text);
                            cmd.Parameters.AddWithValue("@Phone", PhoneTB.Text);
                            cmd.Parameters.AddWithValue("@ZipCode", ZipTB.Text);
                            cmd.Parameters.AddWithValue("@State", StateTB.Text);
                            cmd.ExecuteNonQuery();

                        }
                    }
                    catch (SqlException ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //modify
        {
            var confirmResult = MessageBox.Show("Are you sure you want to Modify this item??",
                                     "Confirm Change!!",
                                     MessageBoxButton.OKCancel);
            string yes = confirmResult.ToString();

            if (yes.Equals("OK"))
            {
                var cs = Properties.Settings.Default.ConnectionString;

                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    try
                    {
                        using (var cmd = new SqlCommand("Update Customers SET Name=@Name, Address=@Address, City=@City, Phone=@Phone, ZipCode=@ZipCode, State=@State WHERE CustomerID=@CustomerID", con))
                        {
                            cmd.Parameters.AddWithValue("@CustomerID", IDSearch.Text);
                            cmd.Parameters.AddWithValue("@Name", NameTB.Text);
                            cmd.Parameters.AddWithValue("@Address", AddressTB.Text);
                            cmd.Parameters.AddWithValue("@City", CityTB.Text);
                            cmd.Parameters.AddWithValue("@Phone", PhoneTB.Text);
                            cmd.Parameters.AddWithValue("@ZipCode", ZipTB.Text);
                            cmd.Parameters.AddWithValue("@State", StateTB.Text);
                            cmd.ExecuteNonQuery();

                        }
                    }
                    catch (SqlException ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }

        }

        private void Button_Click_3(object sender, RoutedEventArgs e) //delete
        {
            var confirmResult = MessageBox.Show("Are you sure you want to Delete this item??",
                                     "Confirm Delete!!",
                                     MessageBoxButton.OKCancel);
            string yes = confirmResult.ToString();

            if (yes.Equals("OK"))
            {
                var cs = Properties.Settings.Default.ConnectionString;

                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    try
                    {
                        using (var cmd = new SqlCommand("DELETE FROM Customers WHERE CustomerID=@CustomerID", con))
                        {
                            cmd.Parameters.AddWithValue("@CustomerID", IDSearch.Text);
                            cmd.ExecuteNonQuery();

                        }
                    }
                    catch (SqlException ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        con.Close();
                    }
                }

            }

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to Exit??",
                                        "Exit?",
                                        MessageBoxButton.OKCancel);
            string yes = confirmResult.ToString();

            if (yes.Equals("OK"))
            {
                App.Current.Shutdown();
            }
        }
        
    }

}
