﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace AppFinal
{
    class ViewModel : ViewModelBase
    {
        private Customer customer1;
        private ObservableCollection<Customer> customer2;
        private ICommand SubmitCommand1;
        public Customer Customer
        {
            get
            {
                return customer1;
            }
            set
            {
                customer1 = value;
                NotifyPropertyChanged("Customers");
            }
        }
        public ObservableCollection<Customer> Customers
        {
            get
            {
                return customer2;
            }
            set
            {
                customer2 = value;
                NotifyPropertyChanged("Customers");
            }
        }
        public ICommand SubmitCommand
        {
            get
            {
                if (SubmitCommand1 == null)
                {
                    SubmitCommand1 = new RelayCommand(param => this.Submit(),
                        null);
                }
                return SubmitCommand1;
            }
        }
        public ViewModel()
        {
            Customer = new Customer();
            Customers = new ObservableCollection<Customer>();
            Customers.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(CustomersCollectionChanged);
        }
        //Whenever new item is added to the collection, am explicitly calling notify property changed
        void CustomersCollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            NotifyPropertyChanged("Customers");
        }
        private void Submit()
        {
            Customers.Add(Customer);
            Customer = new Customer();
        }
    }
}
