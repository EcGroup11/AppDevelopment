﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppFinal
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var cs = Properties.Settings.Default.ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                try
                {
                    using (var cmd = new SqlCommand("SELECT Password FROM Login WHERE Username = @Username", con))
                    {
                        cmd.Parameters.AddWithValue("@Username", UsernameTB.Text);

                        var cmd2 = new SqlCommand("SELECT Username FROM Login WHERE Password = @Password", con);

                        cmd2.Parameters.AddWithValue("@Password", PasswordTB.Password);

                        var password = cmd.ExecuteScalar();
                        var username = cmd2.ExecuteScalar();

                        if (username != null && password != null)
                        {
                            var window = new CustomerEdit();
                            window.Show();
                            var window2 = new MainWindow();
                            window2.Show();
                            Close();
                        }
                        else
                        {
                            ErrorLabel.Content = "Invalid Username or Password";
                        }
                    }
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
