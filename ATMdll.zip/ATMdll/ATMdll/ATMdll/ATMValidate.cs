﻿using System;

namespace ATMdll
{
    class ATMValidate
    {
        public int Balance { get; set; }
        public int Withdraw { get; set; }
        public int Deposit { get; set; }

        public static String WDraw(String B, String W)
        {
            int bal = Convert.ToInt32(B);
            int wit = Convert.ToInt32(W);
            String total;

            if(bal > wit)
            {
                return "null";
            }
            else if(wit < 0)
            {
                return "null";
            }
            else
            {
                bal -= wit;
                total = bal.ToString();
                return total;
            }
            
        }

        public static String Dep(String B, String D)
        {
            int bal = Convert.ToInt32(B);
            int dep = Convert.ToInt32(D);
            String total;

            if(dep < 0)
            {
                return "null";
            }
            else
            {
                bal += dep;
                total = bal.ToString();
                return total;
            }
        }
    }
}
