﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFATM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static String Username = "";

        public MainWindow(String username)
        {
            InitializeComponent();

            Username = username;
            var cs = Properties.Settings.Default.ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                var Username = username;
                String FName = "";
                String LName = "";
                String Balance = "0";
                int Account = 0;

                using (var cmd = new SqlCommand("SELECT AccountID, Balance, FirstName, LastName FROM ATMTABLE WHERE Username = @Username", con))
                {
                    cmd.Parameters.AddWithValue("@Username", Username);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) // Don't assume we have any rows.
                        {
                            int ord = reader.GetOrdinal("FirstName");
                            FName = reader.GetString(ord); // Handles nulls and empty strings.
                            ord = reader.GetOrdinal("LastName");
                            LName = reader.GetString(ord);
                            ord = reader.GetOrdinal("AccountID");
                            Account = reader.GetInt32(ord);
                            ord = reader.GetOrdinal("Balance");
                            Balance = reader.GetString(ord);
                        }

                        FNameText.Text = FName;
                        LNameText.Text = LName;
                        AccountText.Text = Account.ToString();
                        BalanceText.Text = Balance;
                    }
                }

                con.Close();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e) //withdraw
        {
            int Withdraw = Convert.ToInt32(WithText.Text);
            int Balance = Convert.ToInt32(BalanceText.Text);
            if (Withdraw > Balance)
            {
                ErrorMessage.Content = "You Do Not Have Enough In Your Account";
            }
            else if (Withdraw < 0)
            {
                ErrorMessage.Content = "Cannot Withdraw Negative Ammount";
            }
            else
            {
                Balance = Balance - Withdraw;
                BalanceText.Text = Balance.ToString();
                WithText.Text = "";
                ErrorMessage.Content = Balance.ToString();
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //deposit
        {
            int Deposit = Convert.ToInt32(DepText.Text);
            int Balance = Convert.ToInt32(BalanceText.Text);
            if (Deposit < 0)
            {
                ErrorMessage.Content = "Cannot Deposit Negative Ammount";
            }
            else
            {
                Balance = Balance + Deposit;
                BalanceText.Text = Balance.ToString();
                DepText.Text = "";
                ErrorMessage.Content = Balance.ToString();
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //submit
        {
            var cs = Properties.Settings.Default.ConnectionString;

            ErrorMessage.Content = "";

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                using (var cmd = new SqlCommand("UPDATE ATMTABLE SET Balance = @Balance WHERE Username = @Username", con))
                {
                    cmd.Parameters.AddWithValue("@Balance", BalanceText.Text);
                    cmd.Parameters.AddWithValue("@Username", Username);
                    cmd.ExecuteNonQuery();
                }

                con.Close();
                con.Open();

                using (var cmd2 = new SqlCommand("SELECT AccountID, Balance, FirstName, LastName FROM ATMTABLE WHERE Username = @Username", con))
                {
                    cmd2.Parameters.AddWithValue("@Username", Username);

                    String FName = "";
                    String LName = "";
                    int Account = 0;
                    String Balance = "";

                    using (var reader = cmd2.ExecuteReader())
                    {
                        if (reader.Read()) // Don't assume we have any rows.
                        {
                            int ord = reader.GetOrdinal("FirstName");
                            FName = reader.GetString(ord); // Handles nulls and empty strings.
                            ord = reader.GetOrdinal("LastName");
                            LName = reader.GetString(ord);
                            ord = reader.GetOrdinal("AccountID");
                            Account = reader.GetInt32(ord);
                            ord = reader.GetOrdinal("Balance");
                            Balance = reader.GetString(ord);
                        }

                        FNameText.Text = FName;
                        LNameText.Text = LName;
                        AccountText.Text = Account.ToString();
                        BalanceText.Text = Balance;
                    }
                }

                con.Close();
            }

        }
    }
}
