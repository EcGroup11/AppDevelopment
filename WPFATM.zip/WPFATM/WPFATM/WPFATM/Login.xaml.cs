﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFATM
{
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var cs = Properties.Settings.Default.ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                using (var cmd = new SqlCommand("SELECT Password FROM ATMTABLE WHERE Username = @Username", con))
                {
                    cmd.Parameters.AddWithValue("@Username", UsernameText.Text);

                    var cmd2 = new SqlCommand("SELECT Username FROM ATMTABLE WHERE Password = @Password", con);

                    cmd2.Parameters.AddWithValue("@Password", PasswordText.Password);

                    var password = cmd.ExecuteScalar();
                    string username = cmd2.ExecuteScalar().ToString();

                    if (username != null && password != null)
                    {
                        var window = new MainWindow(username);
                        window.Show();
                        Close();
                    }
                    else
                    {
                        ErrorLabel.Content = "Invalid Username or Password";
                    }
                }

                con.Close();
            }

        }
    }
}
